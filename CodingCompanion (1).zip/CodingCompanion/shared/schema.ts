import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User table
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  displayName: text("display_name").notNull(),
  email: text("email").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  displayName: true,
  email: true,
});

// Subjects/Categories table
export const subjects = pgTable("subjects", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  color: text("color").notNull(),
  userId: integer("user_id").notNull(),
});

export const insertSubjectSchema = createInsertSchema(subjects).pick({
  name: true,
  color: true,
  userId: true,
});

// Tasks table
export const tasks = pgTable("tasks", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description"),
  dueDate: timestamp("due_date").notNull(),
  progress: integer("progress").notNull().default(0),
  isCompleted: boolean("is_completed").notNull().default(false),
  subjectId: integer("subject_id").notNull(),
  userId: integer("user_id").notNull(),
  priority: text("priority").notNull().default("medium"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertTaskSchema = createInsertSchema(tasks).pick({
  title: true,
  description: true,
  dueDate: true,
  progress: true,
  isCompleted: true,
  subjectId: true,
  userId: true,
  priority: true,
});

// Events table
export const events = pgTable("events", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  date: timestamp("date").notNull(),
  subjectId: integer("subject_id"),
  userId: integer("user_id").notNull(),
  type: text("type").notNull().default("event"),
});

export const insertEventSchema = createInsertSchema(events).pick({
  title: true,
  date: true,
  subjectId: true,
  userId: true,
  type: true,
});

// Resources table
export const resources = pgTable("resources", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  type: text("type").notNull(),
  url: text("url"),
  subjectId: integer("subject_id").notNull(),
  userId: integer("user_id").notNull(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const insertResourceSchema = createInsertSchema(resources).pick({
  name: true,
  type: true,
  url: true,
  subjectId: true,
  userId: true,
});

// Type declarations
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Subject = typeof subjects.$inferSelect;
export type InsertSubject = z.infer<typeof insertSubjectSchema>;

export type Task = typeof tasks.$inferSelect;
export type InsertTask = z.infer<typeof insertTaskSchema>;

export type Event = typeof events.$inferSelect;
export type InsertEvent = z.infer<typeof insertEventSchema>;

export type Resource = typeof resources.$inferSelect;
export type InsertResource = z.infer<typeof insertResourceSchema>;

// Priority enum
export const TaskPriorityEnum = z.enum(["low", "medium", "high"]);
export type TaskPriority = z.infer<typeof TaskPriorityEnum>;

// Subject colors
export const SubjectColorEnum = z.enum([
  "green", "blue", "purple", "indigo", "amber", "red", "pink", "cyan", "teal", "orange"
]);
export type SubjectColor = z.infer<typeof SubjectColorEnum>;

// Resource types
export const ResourceTypeEnum = z.enum(["pdf", "document", "image", "video", "link", "other"]);
export type ResourceType = z.infer<typeof ResourceTypeEnum>;
