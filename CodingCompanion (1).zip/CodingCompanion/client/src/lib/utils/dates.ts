import { 
  format, 
  formatDistance, 
  formatRelative, 
  parseISO, 
  isToday, 
  isTomorrow, 
  isPast, 
  isThisWeek, 
  differenceInDays, 
  startOfWeek, 
  endOfWeek, 
  eachDayOfInterval 
} from 'date-fns';

/**
 * Format a date with the specified format
 */
export const formatDate = (date: Date | string, formatString: string = 'MMM d, yyyy'): string => {
  const parsedDate = typeof date === 'string' ? parseISO(date) : date;
  return format(parsedDate, formatString);
};

/**
 * Format a date relative to now (e.g., "2 days ago", "in 3 days")
 */
export const formatDistanceToNow = (date: Date | string, options?: { addSuffix?: boolean }): string => {
  const parsedDate = typeof date === 'string' ? parseISO(date) : date;
  return formatDistance(parsedDate, new Date(), { addSuffix: options?.addSuffix || false });
};

/**
 * Format a relative date (e.g., "yesterday", "last Friday")
 */
export const formatRelativeDate = (date: Date | string): string => {
  const parsedDate = typeof date === 'string' ? parseISO(date) : date;
  return formatRelative(parsedDate, new Date());
};

/**
 * Get a user-friendly representation of a due date
 */
export const formatDueDate = (date: Date | string): string => {
  const parsedDate = typeof date === 'string' ? parseISO(date) : date;
  const now = new Date();
  
  if (isToday(parsedDate)) {
    return 'Due today';
  }
  
  if (isTomorrow(parsedDate)) {
    return 'Due tomorrow';
  }
  
  if (isPast(parsedDate)) {
    const days = Math.abs(differenceInDays(parsedDate, now));
    return `Overdue by ${days} ${days === 1 ? 'day' : 'days'}`;
  }
  
  if (isThisWeek(parsedDate)) {
    return `Due on ${format(parsedDate, 'EEEE')}`;
  }
  
  return `Due in ${formatDistance(parsedDate, now)}`;
};

/**
 * Get the days of the current week
 */
export const getDaysOfWeek = (): Date[] => {
  const now = new Date();
  const start = startOfWeek(now);
  const end = endOfWeek(now);
  
  return eachDayOfInterval({ start, end });
};

/**
 * Check if two dates are the same day
 */
export const isSameDay = (date1: Date | string, date2: Date | string): boolean => {
  const parsedDate1 = typeof date1 === 'string' ? parseISO(date1) : date1;
  const parsedDate2 = typeof date2 === 'string' ? parseISO(date2) : date2;
  
  return (
    parsedDate1.getDate() === parsedDate2.getDate() &&
    parsedDate1.getMonth() === parsedDate2.getMonth() &&
    parsedDate1.getFullYear() === parsedDate2.getFullYear()
  );
};

/**
 * Get a formatted date range string (e.g., "Jan 1 - Jan 7, 2023")
 */
export const formatDateRange = (startDate: Date | string, endDate: Date | string): string => {
  const parsedStartDate = typeof startDate === 'string' ? parseISO(startDate) : startDate;
  const parsedEndDate = typeof endDate === 'string' ? parseISO(endDate) : endDate;
  
  if (parsedStartDate.getFullYear() === parsedEndDate.getFullYear()) {
    if (parsedStartDate.getMonth() === parsedEndDate.getMonth()) {
      return `${format(parsedStartDate, 'MMM d')} - ${format(parsedEndDate, 'd, yyyy')}`;
    }
    return `${format(parsedStartDate, 'MMM d')} - ${format(parsedEndDate, 'MMM d, yyyy')}`;
  }
  
  return `${format(parsedStartDate, 'MMM d, yyyy')} - ${format(parsedEndDate, 'MMM d, yyyy')}`;
};
